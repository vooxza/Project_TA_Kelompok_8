import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../controllers/history_controller.dart';
import '../../core/theme/app_colors.dart';
import '../../widgets/history/order_card.dart';
import '../../widgets/history/revenue_card.dart';

/// Versi widescreen dari HistoryPage. Data sama persis (dari
/// [HistoryController.orderList]) — hanya reflow jadi tampilan master-detail:
/// kiri = daftar meja (dikelompokkan dari `table_number` tiap order), kanan =
/// daftar pesanan untuk meja yang dipilih. Memakai `controller.selectedTable`
/// yang sudah tersedia di controller (sebelumnya belum dipakai di versi
/// mobile).
class HistoryPageWide extends GetView<HistoryController> {
  const HistoryPageWide({super.key});

  String _tableLabel(String table) {
    final upper = table.toUpperCase();
    if (upper.startsWith('MEJA')) return upper;
    return 'MEJA $upper';
  }

  Map<String, List> _groupByTable(List orders) {
    final Map<String, List> grouped = {};
    for (final order in orders) {
      final table = (order['table_number'] ?? '-').toString();
      grouped.putIfAbsent(table, () => []).add(order);
    }
    return grouped;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bgGrey,
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 1200),
          child: Container(
            margin: const EdgeInsets.symmetric(vertical: 24, horizontal: 24),
            decoration: BoxDecoration(
              color: AppColors.bgCream,
              borderRadius: BorderRadius.circular(28),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.08),
                  blurRadius: 30,
                  offset: const Offset(0, 12),
                ),
              ],
            ),
            clipBehavior: Clip.antiAlias,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(28, 26, 28, 28),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Riwayat Pesanan',
                    style: TextStyle(
                      fontSize: 26,
                      fontWeight: FontWeight.w800,
                      color: AppColors.textDark,
                      letterSpacing: -0.5,
                    ),
                  ),
                  const SizedBox(height: 18),
                  Expanded(
                    child: Obx(() {
                      if (controller.isLoading.value) {
                        return const Center(
                          child: CircularProgressIndicator(
                            color: AppColors.primaryRed,
                            strokeWidth: 2.5,
                          ),
                        );
                      }

                      final orders = controller.orderList;
                      final grouped = _groupByTable(orders);
                      final tables = grouped.keys.toList()..sort();

                      if (tables.isEmpty) {
                        return const Center(
                          child: Text(
                            'Belum ada pesanan',
                            style: TextStyle(
                              fontSize: 15,
                              color: AppColors.textLight,
                            ),
                          ),
                        );
                      }

                      // Default pilih meja pertama kalau belum ada yang
                      // dipilih / pilihan sebelumnya sudah tidak ada order-nya.
                      if (controller.selectedTable.value == null ||
                          !tables.contains(controller.selectedTable.value)) {
                        WidgetsBinding.instance.addPostFrameCallback((_) {
                          controller.selectedTable.value = tables.first;
                        });
                      }

                      return Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Kiri: daftar meja
                          SizedBox(
                            width: 300,
                            child: ListView.separated(
                              itemCount: tables.length,
                              separatorBuilder: (_, __) =>
                                  const SizedBox(height: 10),
                              itemBuilder: (context, index) {
                                final table = tables[index];
                                final tableOrders = grouped[table]!;
                                final isSelected =
                                    controller.selectedTable.value == table;

                                return GestureDetector(
                                  onTap: () =>
                                      controller.selectedTable.value = table,
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 18, vertical: 16),
                                    decoration: BoxDecoration(
                                      color: isSelected
                                          ? AppColors.primaryRed
                                          : AppColors.bgWhite,
                                      borderRadius: BorderRadius.circular(16),
                                      boxShadow: [
                                        BoxShadow(
                                          color: AppColors.shadowDark,
                                          blurRadius: 8,
                                          offset: const Offset(0, 3),
                                        ),
                                      ],
                                    ),
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Text(
                                          _tableLabel(table),
                                          style: TextStyle(
                                            fontSize: 14,
                                            fontWeight: FontWeight.w800,
                                            color: isSelected
                                                ? Colors.white
                                                : AppColors.textDark,
                                          ),
                                        ),
                                        Row(
                                          mainAxisSize: MainAxisSize.min,
                                          children: [
                                            Text(
                                              'Total Pesanan: ${tableOrders.length}',
                                              style: TextStyle(
                                                fontSize: 12,
                                                fontWeight: FontWeight.w600,
                                                color: isSelected
                                                    ? Colors.white70
                                                    : AppColors.textLight,
                                              ),
                                            ),
                                            const SizedBox(width: 6),
                                            Icon(
                                              Icons.arrow_forward_rounded,
                                              size: 16,
                                              color: isSelected
                                                  ? Colors.white
                                                  : AppColors.textLight,
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                );
                              },
                            ),
                          ),
                          const SizedBox(width: 24),
                          // Kanan: detail pesanan meja terpilih
                          Expanded(
                            child: Obx(() {
                              final table = controller.selectedTable.value;
                              final tableOrders =
                                  table != null ? (grouped[table] ?? []) : [];

                              return Column(
                                crossAxisAlignment:
                                    CrossAxisAlignment.start,
                                children: [
                                  RevenueCard(
                                    controller: controller,
                                    orders: tableOrders,
                                    isAdmin: controller.isAdmin,
                                  ),
                                  Expanded(
                                    child: tableOrders.isEmpty
                                        ? const Center(
                                            child: Text(
                                              'Pilih meja untuk melihat riwayat',
                                              style: TextStyle(
                                                fontSize: 14,
                                                color: AppColors.textLight,
                                              ),
                                            ),
                                          )
                                        : ListView.builder(
                                            padding: const EdgeInsets.fromLTRB(
                                                20, 4, 20, 20),
                                            itemCount: tableOrders.length,
                                            itemBuilder: (context, index) {
                                              return OrderCard(
                                                order: tableOrders[index],
                                                controller: controller,
                                              );
                                            },
                                          ),
                                  ),
                                ],
                              );
                            }),
                          ),
                        ],
                      );
                    }),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
